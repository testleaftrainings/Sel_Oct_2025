package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	@BeforeTest
	public void setValues() {
		excelFileName="Login";
	}
	@Test(dataProvider="fetchData")
	public void runLogin(String uName,String pwd) {
		System.out.println(driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUname(uName).enterPwd(pwd).clickLogin().clickCrmsfa();
		
}
}
