package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import io.cucumber.testng.AbstractTestNGCucumberTests;

public class BaseClass extends AbstractTestNGCucumberTests{
	//public static ChromeDriver driver;
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	public void setDriver() {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("guest");
		cDriver.set(new ChromeDriver(options));
	}
	
	public ChromeDriver getDriver() {
		return cDriver.get();
	}
	@BeforeMethod
	public void precondn() {
		setDriver();//initializing the driver
		 //System.out.println(driver);
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
}
	@AfterMethod
	public void postCondn() {
		getDriver().close();
	
}
}
