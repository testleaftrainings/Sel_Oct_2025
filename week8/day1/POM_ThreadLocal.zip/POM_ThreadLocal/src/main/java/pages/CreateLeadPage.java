package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.When;

public class CreateLeadPage extends BaseClass {
	
	@When("enter the companyname as(.*)$")
	public CreateLeadPage enterCname(String cName) {
		getDriver().findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
		return this;
	}
	@When("Enter the first name as(.*)$")
	public CreateLeadPage enterFname(String fName) {
		getDriver().findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
		return this;
		
	}
	@And("enter the last name as(.*)$")
	public CreateLeadPage enterLname(String lName) {
		getDriver().findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
		return this;
	
}
	@When("Click on create lead button")
	public ViewLeadsPage clickCreateLead() {
		getDriver().findElement(By.name("submitButton")).click();
		return new ViewLeadsPage();
}

}
