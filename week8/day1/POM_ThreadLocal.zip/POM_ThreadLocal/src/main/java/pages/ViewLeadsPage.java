package pages;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.Then;

public class ViewLeadsPage extends BaseClass {
	
	
	@Then("View leads page is displayed")
	public ViewLeadsPage verifyLeads() {
		String text = getDriver().findElement(By.id("viewLead_firstName_sp")).getText();
	    if (text.contains("saranya")) {
			System.out.println("name matched");
		} else {
			System.out.println("name not matched");
		}
	    return this;
	}
	}


