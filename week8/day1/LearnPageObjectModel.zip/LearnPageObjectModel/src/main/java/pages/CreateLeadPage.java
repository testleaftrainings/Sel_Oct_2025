package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class CreateLeadPage extends BaseClass {
	
	public CreateLeadPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public CreateLeadPage enterCname() {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys("Testleaf");
		return this;
	}
	public CreateLeadPage enterFname() {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys("saranya");
		return this;
		
	}
	public CreateLeadPage enterLname() {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys("shanmugam");
		return this;
	
}
	public ViewLeadsPage clickCreateLead() {
		driver.findElement(By.name("submitButton")).click();
		return new ViewLeadsPage(driver);
}

}
