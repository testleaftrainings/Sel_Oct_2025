package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunCreateLead extends BaseClass{

	@Test
	public void runCreateLead() {
		//System.out.println(driver);
		LoginPage lp=new LoginPage(driver);
		lp.enterUname().enterPwd().clickLogin().clickCrmsfa().clickLeads().clickCreateLead().enterCname()
		.enterFname().enterLname().clickCreateLead().verifyLeads();
}
	
}
