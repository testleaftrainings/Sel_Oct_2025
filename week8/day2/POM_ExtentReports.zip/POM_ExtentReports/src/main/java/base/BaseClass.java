package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcelIntegration;

public class BaseClass extends AbstractTestNGCucumberTests{
	public String testName,testDescription,testAuthor,testCategory,excelFileName;
	//public static ChromeDriver driver;
	public static ExtentReports extent;
	public static ExtentTest test;
	private static final ThreadLocal<ChromeDriver> cDriver=new ThreadLocal<ChromeDriver>();
	
	public void setDriver() {
		ChromeOptions options=new ChromeOptions();
		options.addArguments("guest");
		cDriver.set(new ChromeDriver(options));
	}
	
	public ChromeDriver getDriver() {
		return cDriver.get();
	}
	@BeforeSuite
	public void startReports() {
		ExtentHtmlReporter reporter=new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		//instantiate extentReports
		 extent=new ExtentReports();
		//with the filepath,i need to attach the data with the file
		extent.attachReporter(reporter);
	}
	@BeforeClass
	public void testCaseDetails() {
		 test=extent.createTest(testName, testDescription);
		//assign testcategory
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);
	}
	@DataProvider(name="fetchData")
	public String[][] sendData() throws IOException {
		return ReadExcelIntegration.readData(excelFileName);
	}
	public void reportStep(String msg,String status) throws IOException {
		if (status.equalsIgnoreCase("pass")) {
			test.pass(msg,MediaEntityBuilder.createScreenCaptureFromPath("../snap/img"+takeSnap()+".png").build());
		} else if(status.equalsIgnoreCase("fail")) {
			test.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath("../snap/img"+takeSnap()+".png").build());
			throw new RuntimeException("verify the details in the report");
		}
	}
	
	public int takeSnap() throws IOException {
		int ranNum=(int)(Math.random() *999999 + 99999);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File dest=new File("./snap/img"+ranNum+".png");
		FileUtils.copyFile(src, dest);
		return ranNum;
	}
	@BeforeMethod
	public void precondn() {
		setDriver();//initializing the driver
		 //System.out.println(driver);
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().window().maximize();
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
	
}
	@AfterSuite
	public void stopReports() {
		extent.flush();
	}
	@AfterMethod
	public void postCondn() {
		getDriver().close();
	
}
}
