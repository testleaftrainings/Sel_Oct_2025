package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class RunLogin extends BaseClass{
	@BeforeTest
	public void setValues() {
		testName="Login";
		testDescription="Login with multiple data";
		testAuthor="saran";
		testCategory="regression";
		excelFileName="Login";
	}
	@Test(dataProvider="fetchData")
	public void runLogin(String uName,String pwd) throws IOException {
		//System.out.println(driver);
		LoginPage lp=new LoginPage();
		lp.enterUname(uName).enterPwd(pwd).clickLogin().clickCrmsfa();
		
}
}
